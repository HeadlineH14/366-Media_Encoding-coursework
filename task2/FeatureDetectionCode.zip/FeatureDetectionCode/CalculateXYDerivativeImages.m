
InputImage = imread('Neuschwanstein.png'); % Try to replace 'Neuschwanstein.png' with other images as well

%%% missing lines from here
%%% .....
%%% missing lines till here

imagesc(Dxf);
colormap gray;
axis image off;
figure,imagesc(Dyf);
colormap gray;
axis image off;

save Dxf.mat Dxf;
save Dyf.mat Dyf;
