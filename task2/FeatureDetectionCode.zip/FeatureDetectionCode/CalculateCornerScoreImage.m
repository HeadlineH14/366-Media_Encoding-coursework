
load('SQf.mat', 'SQxxf', 'SQxyf', 'SQyyf');

%%% missing lines from here
%%% .....
%%% missing lines till here

save Rf.mat Rf;

imagesc(Rf);
colormap gray;
axis image off;
title('R[f]')
